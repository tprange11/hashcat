/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _INC_LUKS_XTS_H
#define _INC_LUKS_XTS_H

DECLSPEC void xts_mul2 (u32 *in, u32 *out);

#endif // _INC_LUKS_XTS_H
